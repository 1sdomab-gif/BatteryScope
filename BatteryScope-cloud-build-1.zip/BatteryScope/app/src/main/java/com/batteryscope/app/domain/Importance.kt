package com.batteryscope.app.domain

enum class Importance(val label: String, val explanation: String) {
    REVIEW("Проверить", "Расход или активность выглядят необычно; это не доказательство ненужности."),
    LIMIT("Можно ограничить", "Проверьте, не нарушит ли ограничение уведомления или синхронизацию."),
    WATCH("Наблюдение", "Нужно больше истории, чтобы сделать вывод."),
    USEFUL("Полезная функция", "Активность может обеспечивать нужные функции приложения."),
    CRITICAL("Системно важное", "Не отключайте без понимания назначения компонента.")
}

data class ConsumerSnapshot(
    val name: String,
    val detail: String,
    val percent: Float?,
    val backgroundMinutes: Long?,
    val importance: Importance,
    val sourceLabel: String
)
