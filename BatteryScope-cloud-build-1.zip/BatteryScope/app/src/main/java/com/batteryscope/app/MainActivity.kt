package com.batteryscope.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.batteryscope.app.data.BatteryRepository
import com.batteryscope.app.domain.ConsumerSnapshot
import com.batteryscope.app.domain.Importance

private val Ink = androidx.compose.ui.graphics.Color(0xFF101310)
private val Panel = androidx.compose.ui.graphics.Color(0xFF1A201B)
private val Mint = androidx.compose.ui.graphics.Color(0xFF55D6A0)
private val Muted = androidx.compose.ui.graphics.Color(0xFF9BA69D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = BatteryRepository(this)
        setContent { BatteryScopeApp(repository) }
    }
}

@Composable
private fun BatteryScopeApp(repository: BatteryRepository) {
    var battery by remember { mutableStateOf(repository.readBatteryState()) }
    var history by remember { mutableStateOf(repository.recordAndReadBatteryHistory(battery.levelPercent)) }
    var rows by remember { mutableStateOf(repository.readAppUsage24h().let { if (it.hasAccess) it.rows else repository.starterRows() }) }
    var hasUsageAccess by remember { mutableStateOf(repository.hasUsageAccess()) }
    var selectedTab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Mint, onBackground = androidx.compose.ui.graphics.Color.White)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.BatteryFull, null) }, label = { Text("Обзор") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.Bolt, null) }, label = { Text("Потребители") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Info, null) }, label = { Text("О данных") })
            }
        }) { padding ->
            when (selectedTab) {
                0 -> OverviewScreen(battery.levelPercent, battery.isCharging, battery.temperatureC, battery.health, rows, history.map { it.level }, Modifier.padding(padding), onRefresh = { battery = repository.readBatteryState(); history = repository.recordAndReadBatteryHistory(battery.levelPercent); hasUsageAccess = repository.hasUsageAccess(); val result = repository.readAppUsage24h(); rows = if (result.hasAccess) result.rows else repository.starterRows() })
                1 -> ConsumersScreen(rows, hasUsageAccess, Modifier.padding(padding), onGrantAccess = { repository.openUsageAccessSettings() }, onRefresh = { hasUsageAccess = repository.hasUsageAccess(); val result = repository.readAppUsage24h(); rows = if (result.hasAccess) result.rows else repository.starterRows() })
                else -> DataInfoScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun OverviewScreen(level: Int, charging: Boolean, temperature: Float?, health: String, rows: List<ConsumerSnapshot>, history: List<Int>, modifier: Modifier, onRefresh: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("BatteryScope", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("Анализ фонового расхода", color = Muted, fontSize = 13.sp)
                }
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Обновить") }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(26.dp), color = Panel, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(54.dp).background(Mint.copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.BatteryFull, null, tint = Mint, modifier = Modifier.size(30.dp)) }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(if (level >= 0) "$level%" else "—", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Text(if (charging) "Заряжается / полный" else "Работа от аккумулятора", color = Muted, fontSize = 13.sp)
                        }
                    }
                    LinearProgressIndicator(progress = { if (level >= 0) level / 100f else 0f }, modifier = Modifier.fillMaxWidth().height(7.dp), color = Mint, trackColor = androidx.compose.ui.graphics.Color(0xFF333A34))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Metric("Температура", temperature?.let { "%.1f °C".format(it) } ?: "Нет данных")
                        Metric("Состояние", health)
                    }
                }
            }
        }
        item { Text("РАСХОД И АКТИВНОСТЬ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp) }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("История разряда", fontWeight = FontWeight.SemiBold); Text(if (history.size >= 2) "Наблюдения при открытии приложения" else "Накопи несколько измерений", color = Muted, fontSize = 12.sp) }
                        Text("7 дней", color = Mint, fontSize = 12.sp)
                    }
                    BatteryHistoryChart(history, Modifier.fillMaxWidth().height(100.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(if (history.isNotEmpty()) "${history.first()}% · начало" else "Нет измерений", color = Muted, fontSize = 11.sp); Text(if (history.isNotEmpty()) "${history.last()}% · сейчас" else "История не накоплена", color = Muted, fontSize = 11.sp) }
                }
            }
        }
        item { Text("АКТИВНОСТЬ ПРИЛОЖЕНИЙ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp) }
        items(rows.take(3)) { ConsumerRow(it) }
        item {
            Text("Важно: Android не предоставляет всем приложениям точный расход энергии по каждому внутреннему процессу. Неизмеренные значения не подменяются догадками.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun Metric(title: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(title, color = Muted, fontSize = 11.sp); Text(value, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
}

@Composable
private fun BatteryHistoryChart(history: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        for (i in 0..3) {
            val y = h * i / 3f
            drawLine(androidx.compose.ui.graphics.Color(0xFF343B35), Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
        }
        if (history.size >= 2) {
            val pts = history.takeLast(60).mapIndexed { index, value ->
                val x = index.toFloat() / (minOf(history.size, 60) - 1).coerceAtLeast(1) * w
                val y = h - (value.coerceIn(0, 100) / 100f * h)
                Offset(x, y)
            }
            pts.zipWithNext().forEach { (a, b) -> drawLine(Mint, a, b, strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round) }
        } else {
            drawLine(Muted.copy(alpha = .6f), Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 1.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun ConsumersScreen(rows: List<ConsumerSnapshot>, hasUsageAccess: Boolean, modifier: Modifier = Modifier, onGrantAccess: () -> Unit, onRefresh: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 24.dp)) {
        item { Text("Потребители", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Активность приложений · 24 часа", color = Muted) }
        if (!hasUsageAccess) {
            item {
                Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Нужен доступ к статистике", fontWeight = FontWeight.SemiBold)
                        Text("Android откроет системные настройки. Найди BatteryScope и включи доступ к статистике использования, затем вернись сюда и нажми «Обновить».", color = Muted, fontSize = 13.sp, lineHeight = 18.sp)
                        Button(onClick = onGrantAccess, modifier = Modifier.fillMaxWidth()) { Text("Открыть настройки доступа") }
                        OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Обновить статус") }
                    }
                }
            }
        } else {
            item { Text("Список основан на времени использования приложений. Это не рейтинг расхода энергии: Android не раскрывает точные мВт·ч по каждому приложению через этот API.", color = Muted, fontSize = 13.sp, lineHeight = 18.sp) }
            item { OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Обновить") } }
            if (rows.isEmpty()) item { Text("За выбранный период статистика не найдена. Попробуй позже.", color = Muted, fontSize = 13.sp) }
        }
        items(rows) { ConsumerRow(it) }
    }
}

@Composable
private fun ConsumerRow(row: ConsumerSnapshot) {
    val color = when (row.importance) {
        Importance.REVIEW -> androidx.compose.ui.graphics.Color(0xFFE16C65)
        Importance.LIMIT -> androidx.compose.ui.graphics.Color(0xFFE5A45B)
        Importance.WATCH -> androidx.compose.ui.graphics.Color(0xFFE0C35D)
        Importance.USEFUL -> androidx.compose.ui.graphics.Color(0xFF6AADE8)
        Importance.CRITICAL -> Mint
    }
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.padding(top = 5.dp).size(9.dp).background(color, CircleShape))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(row.name, fontWeight = FontWeight.SemiBold)
                Text(row.detail, color = Muted, fontSize = 12.sp)
                Text(row.importance.label, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Text(row.importance.explanation, color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                Text(row.sourceLabel, color = Muted.copy(alpha = .8f), fontSize = 10.sp)
            }
            Text(row.percent?.let { "%.1f%%".format(it) } ?: "—", fontWeight = FontWeight.Bold, color = if (row.percent == null) Muted else androidx.compose.ui.graphics.Color.White)
        }
    }
}

@Composable
private fun DataInfoScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("О данных", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Обычный режим", fontWeight = FontWeight.SemiBold)
        Text("Показывает заряд, температуру и состояние батареи, а также будет использовать системные API и разрешённую статистику использования. Android ограничивает видимость других приложений и внутренних процессов.", color = Muted, fontSize = 14.sp, lineHeight = 20.sp)
        HorizontalDivider(color = Panel)
        Text("Расширенный режим (root)", fontWeight = FontWeight.SemiBold)
        Text("Отдельный адаптер сможет читать дополнительные доступные на конкретной прошивке счётчики и сведения о процессах. Перед запуском команд потребуется явное согласие пользователя; по умолчанию — только чтение.", color = Muted, fontSize = 14.sp, lineHeight = 20.sp)
        HorizontalDivider(color = Panel)
        Text("Прозрачность", fontWeight = FontWeight.SemiBold)
        Text("Каждый показатель должен иметь источник, временной диапазон и отметку точности: измерено, получено из системной статистики или оценено. Нулевые и отсутствующие данные не считаются доказательством отсутствия расхода.", color = Muted, fontSize = 14.sp, lineHeight = 20.sp)
    }
}
