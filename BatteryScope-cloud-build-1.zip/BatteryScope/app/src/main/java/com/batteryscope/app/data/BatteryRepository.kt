package com.batteryscope.app.data

import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Process
import android.provider.Settings
import com.batteryscope.app.domain.ConsumerSnapshot
import com.batteryscope.app.domain.Importance
import java.util.concurrent.TimeUnit

/** Collects public Android data. Usage duration is NOT treated as battery-energy attribution. */
class BatteryRepository(private val context: Context) {
    data class BatteryState(
        val levelPercent: Int,
        val isCharging: Boolean,
        val temperatureC: Float?,
        val health: String,
        val currentNowMicroAmps: Int?,
        val chargeCounterMicroAh: Int?
    )

    data class UsageResult(val hasAccess: Boolean, val rows: List<ConsumerSnapshot>, val rangeLabel: String = "За последние 24 часа")
    data class BatterySample(val timestamp: Long, val level: Int)

    fun readBatteryState(): BatteryState {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) (level * 100f / scale).toInt() else -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val healthCode = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val health = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Хорошее"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Перегрев"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Неисправность"
            BatteryManager.BATTERY_HEALTH_COLD -> "Низкая температура"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Перенапряжение"
            else -> "Неизвестно"
        }
        val manager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val current = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).takeIf { it != Int.MIN_VALUE && it != 0 }
        val charge = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).takeIf { it != Int.MIN_VALUE && it >= 0 }
        return BatteryState(
            levelPercent = percent,
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            temperatureC = if (tempTenths >= 0) tempTenths / 10f else null,
            health = health,
            currentNowMicroAmps = current,
            chargeCounterMicroAh = charge
        )
    }

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettings() {
        context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun readAppUsage24h(): UsageResult {
        if (!hasUsageAccess()) return UsageResult(false, emptyList())
        val manager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val start = end - TimeUnit.HOURS.toMillis(24)
        val stats = try {
            manager.queryAndAggregateUsageStats(start, end).values
        } catch (_: SecurityException) {
            emptyList<UsageStats>()
        }
        val pm = context.packageManager
        val rows = stats.asSequence()
            .filter { it.totalTimeInForeground > 0L && it.packageName != context.packageName }
            .sortedByDescending { it.totalTimeInForeground }
            .take(100)
            .map { stat ->
                val appName = try {
                    val info = pm.getApplicationInfo(stat.packageName, 0)
                    pm.getApplicationLabel(info).toString()
                } catch (_: PackageManager.NameNotFoundException) {
                    stat.packageName
                } catch (_: SecurityException) {
                    stat.packageName
                }
                val minutes = TimeUnit.MILLISECONDS.toMinutes(stat.totalTimeInForeground)
                ConsumerSnapshot(
                    name = appName,
                    detail = "$minutes мин активности на экране за 24 ч · ${stat.packageName}",
                    percent = null,
                    backgroundMinutes = null,
                    importance = Importance.WATCH,
                    sourceLabel = "Источник: UsageStatsManager. Это не расход батареи и не фоновое время."
                )
            }.toList()
        return UsageResult(true, rows)
    }

    /** Stores real observed charge levels locally. Samples are taken when the app is opened/refreshed. */
    fun recordAndReadBatteryHistory(level: Int): List<BatterySample> {
        if (level !in 0..100) return readBatteryHistory()
        val prefs = context.getSharedPreferences("battery_history", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val existing = readBatteryHistory().toMutableList()
        val last = existing.lastOrNull()
        if (last == null || now - last.timestamp >= TimeUnit.MINUTES.toMillis(5) || last.level != level) {
            existing.add(BatterySample(now, level))
        }
        val cutoff = now - TimeUnit.DAYS.toMillis(7)
        val trimmed = existing.filter { it.timestamp >= cutoff }.takeLast(500)
        prefs.edit().putString("samples", trimmed.joinToString(";") { "${it.timestamp},${it.level}" }).apply()
        return trimmed
    }

    fun readBatteryHistory(): List<BatterySample> {
        val raw = context.getSharedPreferences("battery_history", Context.MODE_PRIVATE).getString("samples", "") ?: ""
        return raw.split(';').mapNotNull { item ->
            val parts = item.split(',')
            if (parts.size != 2) null else {
                val time = parts[0].toLongOrNull()
                val level = parts[1].toIntOrNull()
                if (time != null && level != null && level in 0..100) BatterySample(time, level) else null
            }
        }
    }

    fun starterRows(): List<ConsumerSnapshot> = listOf(
        ConsumerSnapshot("Статистика приложений", "Разрешите доступ к статистике использования, чтобы увидеть активность приложений", null, null, Importance.WATCH, "Ожидается разрешение Android"),
        ConsumerSnapshot("Расход энергии по процессам", "Android не предоставляет точные значения для каждого процесса всем приложениям", null, null, Importance.WATCH, "Источник пока недоступен"),
        ConsumerSnapshot("Расширенный режим", "Root-диагностика будет подключаться отдельно и работать только на чтение по умолчанию", null, null, Importance.USEFUL, "Root сейчас не обнаружен / не настроен")
    )
}
