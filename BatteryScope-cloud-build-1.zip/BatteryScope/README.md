# BatteryScope 0.2.0

Минималистичный Android-проект для локального анализа батареи и доступной статистики использования приложений. Подготовлен с расчётом на Xiaomi 17 / HyperOS beta, без обязательного root.

## Реализовано в этой версии
- Kotlin + Jetpack Compose, тёмный интерфейс.
- Заряд, статус зарядки, температура и состояние батареи через `ACTION_BATTERY_CHANGED`.
- Попытка чтения текущего тока и счётчика заряда через `BatteryManager` (если аппарат предоставляет значения; пока отображение в UI не подключено).
- Проверка специального доступа Usage Access через `AppOpsManager`.
- Экран-переход в системные настройки Usage Access и кнопка повторной проверки.
- Список приложений за последние 24 часа на основе `UsageStatsManager`, с временем использования на переднем плане и именем пакета.
- Локальная история уровня заряда за 7 дней и график фактически собранных наблюдений. Замеры добавляются при открытии приложения/ручном обновлении, не в постоянном фоне.
- Явные пояснения: время на переднем плане не равно фоновому времени и не является энергопотреблением. Энергия по приложениям не выдумывается.
- Убрано объявление `BATTERY_STATS`: это защищённое системное разрешение, которое обычное стороннее приложение не получает простым добавлением в manifest.

## Сборка
1. Открой папку `BatteryScope` в Android Studio.
2. Установи Android SDK Platform 36 и синхронизируй Gradle.
3. Запусти на устройстве. На Android 17 beta приложение использует публичные API старших версий; реальная совместимость должна быть проверена на конкретной сборке HyperOS.
4. Открой вкладку «Потребители» → «Открыть настройки доступа» → разреши BatteryScope доступ к статистике использования → вернись в приложение → «Обновить».

Проект собирается с `compileSdk = 36` и `targetSdk = 36` для предсказуемой совместимости инструментов. Это не означает, что проект уже протестирован на Android 17 beta; сборку и поведение на Xiaomi 17 нужно проверить физически.

## Ограничения
- `UsageStatsManager` показывает использование приложений, в частности время на переднем плане. Он не даёт точные мВт·ч по каждому приложению или внутреннему процессу.
- История заряда пока накапливается только при открытии приложения/ручном обновлении; непрерывный фоновый сбор не реализован.
- `QUERY_ALL_PACKAGES` нужен для показа названий всех пакетов в инструменте такого типа; распространение через Google Play требует проверки правил видимости пакетов и обоснования разрешения.
- Root-режим пока не реализован. Он должен быть отдельным opt-in модулем, по умолчанию только чтение, с обнаружением возможностей конкретной прошивки вместо предположения, что любой файл/команда доступен.
- Внутренние процессы Android и системные службы не могут быть полностью перечислены и точно оценены обычным сторонним приложением.

## Следующие этапы
1. Добавить Room для истории измерений и источников данных.
2. Добавить безопасный фоновый сбор через WorkManager (с учётом системных ограничений; не обещать точный интервал).
3. Улучшить график: временные метки, изменение уровня заряда и отметки подключённой зарядки.
4. Добавить диагностику root-возможностей и отдельные адаптеры для доступных на конкретной прошивке источников, без автоматического отключения процессов.
5. Протестировать на реальном Xiaomi 17 / HyperOS 4 Beta / Android 17.

## Build an APK in the cloud (phone-only workflow)

This project includes `.github/workflows/build-apk.yml` for a GitHub Actions build. It creates a **debug APK** artifact; it does not sign a release build for Play Store distribution.

1. On your phone, open GitHub in a browser and create a new repository named `BatteryScope`.
2. Upload the **contents** of this project folder to the repository (not the ZIP file itself). Keep the `.github/workflows/build-apk.yml` path intact. If GitHub's mobile uploader makes folders difficult, use GitHub's web editor to create/upload the files or a Git client app.
3. Open the repository's **Actions** tab and select **Build BatteryScope APK**. Tap **Run workflow** if it has not started automatically.
4. When the workflow finishes successfully, open that run and download the `BatteryScope-debug-apk` artifact.
5. Extract the downloaded artifact ZIP on your phone; it contains `app-debug.apk`. Open it to install, allowing installation from your browser/files app if Android asks.

The build has not been run in this environment because Android SDK/Gradle are not installed here and outbound network access is unavailable. The workflow is prepared but its success must be confirmed by GitHub Actions. Beta firmware compatibility also needs on-device testing.
